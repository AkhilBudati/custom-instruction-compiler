import re

def lexer(expression):
    token_spec = [
        ('NUMBER', r'\d+'),
        ('ID', r'[A-Za-z_]\w*'),
        ('OP', r'[+\-*/()]'),
        ('SKIP', r'[ \t\n]+'),
        ('MISMATCH', r'.'),
    ]
    tok_regex = '|'.join(f'(?P<{name}>{pattern})' for name, pattern in token_spec)
    tokens = []
    for match in re.finditer(tok_regex, expression):
        kind = match.lastgroup
        value = match.group()
        if kind == 'SKIP':
            continue
        elif kind == 'MISMATCH':
            raise SyntaxError(f"Unexpected token: {value}")
        tokens.append((kind, value))
    return tokens
