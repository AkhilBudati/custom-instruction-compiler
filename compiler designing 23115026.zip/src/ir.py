def optimize(ir):
    if ir[0][0] == 'EXPR':
        result = eval(ir[0][1])
        return [('LOAD_CONST', result)]
    return ir
