def codegen(ir, var_name="result"):
    if ir[0][0] == 'LOAD_CONST':
        return f"{var_name} = {ir[0][1]}"
    return ""
