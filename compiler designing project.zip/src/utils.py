import re

def read_variables(filename):
    variables = {}
    with open(filename, "r") as file:
        for line in file:
            if "=" in line:
                var, val = line.strip().split("=")
                variables[var.strip()] = int(val.strip())
    return variables

def replace_variables(expression, variables):
    for var, val in variables.items():
        expression = re.sub(rf'\b{var}\b', str(val), expression)
    return expression
