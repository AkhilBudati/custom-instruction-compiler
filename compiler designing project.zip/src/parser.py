def generate_ir_from_expression(expression):
    return [('EXPR', expression)]
