from lexer import lexer
from parser import generate_ir_from_expression
from ir import optimize
from codegen import codegen
from utils import read_variables, replace_variables

def main():
    try:
        expression = "(a*b)+(c*d)"
        print("Original Expression:", expression)

        variables = read_variables("input.txt")
        print("Variable Values:", variables)

        evaluated_expr = replace_variables(expression, variables)
        print("Expression after substitution:", evaluated_expr)

        tokens = lexer(evaluated_expr)
        print("Tokens:", tokens)

        ir = generate_ir_from_expression(evaluated_expr)
        print("Intermediate Representation:", ir)

        optimized_ir = optimize(ir)
        print("Optimized IR:", optimized_ir)

        final_code = codegen(optimized_ir)
        print("Generated Code:\n", final_code)

        local_vars = {}
        exec(final_code, {}, local_vars)
        print("Final Result:", local_vars["result"])

    except Exception as e:
        print("Error:", e)

if __name__ == "__main__":
    main()
